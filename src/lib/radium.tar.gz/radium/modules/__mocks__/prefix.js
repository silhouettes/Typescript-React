'use strict';

var prefixMock = function (style) {
  return style;
};

module.exports = prefixMock;
